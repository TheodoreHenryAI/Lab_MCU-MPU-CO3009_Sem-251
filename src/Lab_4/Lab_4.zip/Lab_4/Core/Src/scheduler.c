/*
 * scheduler.c
 *
 *  Created on: Oct 28, 2025
 *      Author: Thanh
 */

#include "scheduler.h"
#include <string.h> // for memset

sTask SCH_tasks_G[SCH_MAX_TASKS];
unsigned char Error_code_G = 0;
static unsigned char Last_error_code_G = 0;
static uint32_t Error_tick_count_G = 0;

void SCH_Init(void) {
    unsigned char i;
    for (i = 0; i < SCH_MAX_TASKS; i++) {
        SCH_tasks_G[i].pTask = 0;
        SCH_tasks_G[i].Delay = 0;
        SCH_tasks_G[i].Period = 0;
        SCH_tasks_G[i].RunMe = 0;
        SCH_tasks_G[i].TaskID = i;
    }
    Error_code_G = 0;
    // Start/configure your 10ms timer here (or call Timer_init from main)
    // Timer_init();   // optionally call a timer init helper
}

void SCH_Update(void) {
    unsigned char Index;
    for (Index = 0; Index < SCH_MAX_TASKS; Index++) {
        if (SCH_tasks_G[Index].pTask) {
            if (SCH_tasks_G[Index].Delay == 0) {
                SCH_tasks_G[Index].RunMe += 1;
                if (SCH_tasks_G[Index].Period) {
                    SCH_tasks_G[Index].Delay = SCH_tasks_G[Index].Period;
                }
            } else {
                SCH_tasks_G[Index].Delay -= 1;
            }
        }
    }
}

unsigned char SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD) {
    unsigned char Index = 0;
    while ((SCH_tasks_G[Index].pTask != 0) && (Index < SCH_MAX_TASKS)) {
        Index++;
    }

    if (Index == SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_TOO_MANY_TASKS;
        return SCH_MAX_TASKS; // error
    }

    SCH_tasks_G[Index].pTask = pFunction;
    SCH_tasks_G[Index].Delay = DELAY;
    SCH_tasks_G[Index].Period = PERIOD;
    SCH_tasks_G[Index].RunMe = 0;
    SCH_tasks_G[Index].TaskID = Index;
    return Index; // return task ID (index)
}

unsigned char SCH_Delete_Task(const uint32_t TASK_INDEX) {
    unsigned char Return_code;
    if (TASK_INDEX >= SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
        return 1; // error
    }
    if (SCH_tasks_G[TASK_INDEX].pTask == 0) {
        Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
        Return_code = 1; // error
    } else {
        Return_code = 0; // normal
    }
    SCH_tasks_G[TASK_INDEX].pTask = 0;
    SCH_tasks_G[TASK_INDEX].Delay = 0;
    SCH_tasks_G[TASK_INDEX].Period = 0;
    SCH_tasks_G[TASK_INDEX].RunMe = 0;
    return Return_code;
}

void SCH_Dispatch_Tasks(void) {
    unsigned char Index;
    for (Index = 0; Index < SCH_MAX_TASKS; Index++) {
        if (SCH_tasks_G[Index].RunMe > 0) {
            (*SCH_tasks_G[Index].pTask)();    // Run the task
            SCH_tasks_G[Index].RunMe -= 1;    // Reset/reduce RunMe
            if (SCH_tasks_G[Index].Period == 0) {
                SCH_Delete_Task(Index);       // remove one-shot
            }
        }
    }
    SCH_Report_Status();
    SCH_Go_To_Sleep(); // optional: put MCU to idle here if desired
}

void SCH_Report_Status(void) {
    // Optional error reporting: e.g. show on LED port or serial.
    if (Error_code_G != Last_error_code_G) {
        Last_error_code_G = Error_code_G;
        if (Error_code_G != 0) {
            Error_tick_count_G = 60000; // as doc (1 minute @ 1ms tick)
        } else {
            Error_tick_count_G = 0;
        }
    } else {
        if (Error_tick_count_G != 0) {
            if (--Error_tick_count_G == 0) {
                Error_code_G = 0;
            }
        }
    }
}

void SCH_Go_To_Sleep(void) {
    // Optional: put MCU in low-power idle; for example, __WFI() in ARM Cortex
    // __WFI();
}
