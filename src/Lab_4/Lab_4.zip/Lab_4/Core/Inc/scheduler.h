/*
 * scheduler.h
 *
 *  Created on: Oct 28, 2025
 *      Author: Thanh
 */

#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdint.h>

#define SCH_MAX_TASKS 40
#define NO_TASK_ID    0xFF

// Error codes (examples)
#define ERROR_SCH_TOO_MANY_TASKS      1
#define ERROR_SCH_CANNOT_DELETE_TASK  2

typedef struct {
    void (*pTask)(void);    // pointer to task function
    uint32_t Delay;         // ticks until next run
    uint32_t Period;        // period in ticks (0 = one-shot)
    uint8_t  RunMe;         // number of times task is due to run
    uint32_t TaskID;        // optional ID (position)
} sTask;

extern sTask SCH_tasks_G[SCH_MAX_TASKS];
extern unsigned char Error_code_G;

void SCH_Init(void);
void SCH_Update(void); // called from timer ISR
void SCH_Dispatch_Tasks(void);
unsigned char SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD);
unsigned char SCH_Delete_Task(const uint32_t TASK_INDEX);
void SCH_Report_Status(void);
void SCH_Go_To_Sleep(void);

#endif // SCHEDULER_H
