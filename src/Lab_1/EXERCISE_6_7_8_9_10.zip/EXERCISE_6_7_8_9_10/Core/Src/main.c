/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - 12 LED clock simulation
  *
  * Exercises included:
  *  - Exercise 6: LED sequence test (original simple test)
  *  - Exercise 7: clearAllClock() - turn off all 12 LEDs
  *  - Exercise 8: setNumberOnClock(num) - turn ON specific LED (clears others)
  *  - Exercise 9: clearNumberOnClock(num) - turn OFF specific LED
  *  - Exercise 10: Integrated Clock System (hour/minute/second LEDs using 12 LEDs)
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f1xx_hal.h"   // adjust if using different STM32 family
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
/* List of LED pins from PA4 to PA15 (index 0 -> PA4, index 11 -> PA15) */
uint16_t LED_Pins[12] = {
  GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7,
  GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10, GPIO_PIN_11,
  GPIO_PIN_12, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */
/* Exercise 7: clear all LEDs */
void clearAllClock(void);

/* Exercise 8: set number on clock (turn ON specific LED; clears others) */
void setNumberOnClock(int num);

/* Exercise 9: clear number on clock (turn OFF specific LED) */
void clearNumberOnClock(int num);

/* Helper used by the integrated clock (does NOT clear other LEDs): */
void setSingleLedOn(int num);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* Exercise 7: implementation of clearAllClock() */
void clearAllClock(void) {
  for (int i = 0; i < 12; i++) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[i], GPIO_PIN_RESET);
  }
}

/* Exercise 8: implementation of setNumberOnClock()
   Clears all LEDs first, then lights the requested one. */
void setNumberOnClock(int num) {
  clearAllClock(); /* per Exercise 8 spec */
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_SET);
  }
}

/* Exercise 9: implementation of clearNumberOnClock()
   Turns OFF only the specified LED (leaves others unchanged). */
void clearNumberOnClock(int num) {
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_RESET);
  }
}

/* Helper: setSingleLedOn(int num)
   Turns ON a single LED without changing other LEDs (used by integrated clock). */
void setSingleLedOn(int num) {
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_SET);
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();

  /* USER CODE BEGIN 2 */
  /* Start with all LEDs OFF (Exercise 7) */
  clearAllClock();
  /* USER CODE END 2 */

  /* -------------------------
     Integrated Clock Variables
     - second_pos, minute_pos, hour_pos hold positions 0..11 (0 -> PA4, 11 -> PA15)
     - All three start at the same position (change initial values here if desired)
     ------------------------- */
  int second_pos = 0;
  int minute_pos = 0;
  int hour_pos   = 0;

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* -------------------------
       Exercise 10: Integrated Clock System
       Behavior:
         * Exactly three LEDs represent hour, minute and second.
         * All three start at same position.
         * second_pos advances by 1 every second.
         * When second_pos wraps (11 -> 0), minute_pos advances by 1.
         * When minute_pos wraps, hour_pos advances by 1.
       ------------------------- */

    /* Turn on hour, minute, second LEDs (clear then set)
       We clear first to avoid lingering previous states. */
    clearAllClock();
    setSingleLedOn(hour_pos);   /* Hour LED */
    setSingleLedOn(minute_pos); /* Minute LED */
    setSingleLedOn(second_pos); /* Second LED */

    /* Wait one second for the next tick (adjust if you want faster/slower) */
    HAL_Delay(1000);

    /* Advance second */
    second_pos = (second_pos + 1) % 12;

    /* When seconds wrapped, advance minute. When minute wraps, advance hour. */
    if (second_pos == 0) {
      minute_pos = (minute_pos + 1) % 12;
      if (minute_pos == 0) {
        hour_pos = (hour_pos + 1) % 12;
      }
    }

    /* Loop back and update LEDs */

/* Exercise 6: LED sequence test */
    //for (int i = 0; i < 12; i++) {
      //HAL_GPIO_WritePin(GPIOA, LED_Pins[i], GPIO_PIN_SET);   // Turn ON LED[i]
      //HAL_Delay(200);                                        // Small delay
      //HAL_GPIO_WritePin(GPIOA, LED_Pins[i], GPIO_PIN_RESET); // Turn OFF LED[i]
    //}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* Configure GPIO pins : PA4 -> PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|
                        GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|
                        GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Start with all LEDs OFF */
  HAL_GPIO_WritePin(GPIOA,
                    GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|
                    GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|
                    GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15,
                    GPIO_PIN_RESET);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER can add custom error print here */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

