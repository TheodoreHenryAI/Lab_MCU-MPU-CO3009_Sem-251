/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - 12 LED clock simulation
  *
  * Exercises included:
  *  - Exercise 6: LED sequence test (original simple test)
  *  - Exercise 7: clearAllClock() - turn off all 12 LEDs
  *  - Exercise 8: setNumberOnClock(num) - turn ON specific LED (clears others)
  *  - Exercise 9: clearNumberOnClock(num) - turn OFF specific LED
  *  - Exercise 10: Integrated Clock System (hour/minute/second LEDs using 12 LEDs)
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f1xx_hal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
uint16_t LED_Pins[12] = {
  GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7,
  GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10, GPIO_PIN_11,
  GPIO_PIN_12, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */
void clearAllClock(void);

void setNumberOnClock(int num);

void clearNumberOnClock(int num);

void setSingleLedOn(int num);

void refreshClockDisplay(int hour_pos, int minute_pos, int second_pos,
                         int hour_on, int minute_on, int second_on);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
void clearAllClock(void) {
  for (int i = 0; i < 12; i++) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[i], GPIO_PIN_RESET);
  }
}

void setNumberOnClock(int num) {
  clearAllClock();
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_SET);
  }
}

void clearNumberOnClock(int num) {
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_RESET);
  }
}

void setSingleLedOn(int num) {
  if (num >= 0 && num < 12) {
    HAL_GPIO_WritePin(GPIOA, LED_Pins[num], GPIO_PIN_SET);
  }
}

void refreshClockDisplay(int hour_pos, int minute_pos, int second_pos,
                         int hour_on, int minute_on, int second_on)
{
  for (int i = 0; i < 12; i++) {
    GPIO_PinState newState = GPIO_PIN_RESET;

    if (hour_on && i == hour_pos)           newState = GPIO_PIN_SET;
    if (minute_on && i == minute_pos)       newState = GPIO_PIN_SET;
    if (second_on && i == second_pos)       newState = GPIO_PIN_SET;

    HAL_GPIO_WritePin(GPIOA, LED_Pins[i], newState);
  }
}
/* USER CODE END 0 */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();

  /* USER CODE BEGIN 2 */
  clearAllClock();
  /* USER CODE END 2 */
  int second_pos = 0;
  int minute_pos = 0;
  int hour_pos   = 0;

  const int tick_ms = 100;
  const int ticks_per_second = 1000 / tick_ms;
  const int second_toggle_interval = 1;
  const int minute_toggle_interval = 5;

  int tick_count = 0;
  int second_visible = 1;
  int minute_visible = 1;
  int hour_visible = 1;

  /* USER CODE BEGIN WHILE */
  while (1)
  {
	    HAL_Delay(tick_ms);
	    tick_count++;

	    if ((tick_count % second_toggle_interval) == 0) {
	      second_visible = !second_visible;
	    }

	    if ((tick_count % minute_toggle_interval) == 0) {
	      minute_visible = !minute_visible;
	    }

	    if ((tick_count % ticks_per_second) == 0) {
	      second_pos = (second_pos + 1) % 12;

	      if (second_pos == 0) {
	        minute_pos = (minute_pos + 1) % 12;
	        if (minute_pos == 0) {
	          hour_pos = (hour_pos + 1) % 12;
	        }
	      }
	    }
	    refreshClockDisplay(hour_pos, minute_pos, second_pos,
	                        hour_visible, minute_visible, second_visible);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* Configure GPIO pins : PA4 -> PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|
                        GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|
                        GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Start with all LEDs OFF */
  HAL_GPIO_WritePin(GPIOA,
                    GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|
                    GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|
                    GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15,
                    GPIO_PIN_RESET);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER can add custom error print here */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

