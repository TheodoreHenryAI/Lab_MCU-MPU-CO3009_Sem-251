/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - Digital clock with software timers
  ******************************************************************************
  * @attention
  *
  * Licensed under BSD 3-Clause license.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdint.h"

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* display buffer and control */
#define MAX_LED 4
volatile int index_led = 0;
volatile int led_buffer[4] = {1,2,3,0};   /* HH:MM buffer */

/* clock variables (main loop) */
int hour = 15, minute = 8, second = 50;

/* multiplexer step: 250 ms per digit -> 4*250ms = 1s full cycle */
#define MUX_PERIOD_MS 250

/* Software timers (TIMER_CYCLE must equal ISR tick period = 10 ms) */
volatile int timer0_counter = 0; /* 1s timer (clock tick) */
volatile int timer0_flag = 0;

volatile int timer1_counter = 0; /* 250ms timer (multiplex step) */
volatile int timer1_flag = 0;

int TIMER_CYCLE = 10; /* ms, ISR tick period */

/* DOT and LED_RED states (handled in main on timer0 expiry) */
int dot_state = 0;
int led_state = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
/* helper prototypes */
void update7SEG(int index);
void updateClockBuffer(void);

/* software-timer helpers */
void setTimer0(int duration_ms);
void setTimer1(int duration_ms);
void timer_run(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* EN polarity - change if your hardware uses opposite polarity */
#define EN_ACTIVE    GPIO_PIN_RESET
#define EN_INACTIVE  GPIO_PIN_SET

/* segment patterns for digits 0..9 (bit0=SEG0(a), bit1=SEG1(b), ..., bit6=SEG6(g)) */
const uint8_t seg_pattern_for_digits[10] =
{
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5),        /*0*/
  (1<<1)|(1<<2),                                    /*1*/
  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6),               /*2*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6),               /*3*/
  (1<<5)|(1<<6)|(1<<1)|(1<<2),                      /*4*/
  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3),               /*5*/
  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6),        /*6*/
  (1<<0)|(1<<1)|(1<<2),                             /*7*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), /*8*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6)         /*9*/
};

/* low-level helpers to write segments and EN lines */
static void set_segments_from_pattern(uint8_t pattern)
{
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static void disable_all_en(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
}

static void enable_en(uint8_t idx)
{
  disable_all_en();
  switch(idx) {
    case 0: HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE); break;
    case 1: HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE); break;
    case 2: HAL_GPIO_WritePin(GPIOA, EN2_Pin, EN_ACTIVE); break;
    case 3: HAL_GPIO_WritePin(GPIOA, EN3_Pin, EN_ACTIVE); break;
    default: break;
  }
}

/* --------------------------------------------------------------------------
   update7SEG(int index) - moved out of ISR, called from main when timer1_flag
   index: 0..3 -> display led_buffer[index] on that 7-seg
   --------------------------------------------------------------------------*/
void update7SEG(int index)
{
  if (index < 0 || index >= MAX_LED) return;

  int val = led_buffer[index];
  if (val < 0) val = 0;
  if (val > 9) val = 0; /* safeguard */

  uint8_t pattern = seg_pattern_for_digits[val];

  /* safe update: disable all, set segments, enable selected */
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en((uint8_t)index);
}

/* --------------------------------------------------------------------------
   updateClockBuffer: fill led_buffer[] from hour/minute (leading zeros)
   --------------------------------------------------------------------------*/
void updateClockBuffer(void)
{
  int h = hour;
  int m = minute;

  if (h < 0) h = 0;
  if (h >= 24) h %= 24;
  if (m < 0) m = 0;
  if (m >= 60) m %= 60;

  led_buffer[0] = (h / 10) % 10;
  led_buffer[1] = h % 10;
  led_buffer[2] = (m / 10) % 10;
  led_buffer[3] = m % 10;
}

/* --------------------------------------------------------------------------
   Software timer API
   timer_run() must be called in ISR every TIMER_CYCLE ms
   --------------------------------------------------------------------------*/
void setTimer0(int duration_ms)
{
  timer0_counter = duration_ms / TIMER_CYCLE;
  timer0_flag = 0;
}
void setTimer1(int duration_ms)
{
  timer1_counter = duration_ms / TIMER_CYCLE;
  timer1_flag = 0;
}

/* called from ISR */
void timer_run(void)
{
  if (timer0_counter > 0) {
    timer0_counter--;
    if (timer0_counter == 0) timer0_flag = 1;
  }
  if (timer1_counter > 0) {
    timer1_counter--;
    if (timer1_counter == 0) timer1_flag = 1;
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* start timer interrupt (10 ms tick) */
  HAL_TIM_Base_Start_IT(&htim2);

  /* initialize time display buffer */
  updateClockBuffer();

  /* initialize timers:
     timer0 -> 1s clock tick (advance seconds, toggle DOT and LED_RED)
     timer1 -> 250ms multiplex step (advance displayed digit)
  */
  setTimer0(1000);
  setTimer1(MUX_PERIOD_MS);

  /* ensure initial display is shown */
  index_led = 0;
  update7SEG(index_led);

  /* main loop: all processing happens here when software timers expire */
  while (1)
  {
    /* 1 second tasks */
    if (timer0_flag) {
      timer0_flag = 0;
      setTimer0(1000); /* restart 1s timer */

      /* advance clock */
      second++;
      if (second >= 60) { second = 0; minute++; }
      if (minute >= 60) { minute = 0; hour++; }
      if (hour >= 24)   { hour = 0; }

      /* refresh display buffer */
      updateClockBuffer();

      /* toggle DOT (PA4) and LED_RED (PAx) */
      dot_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, DOT_Pin, (dot_state ? GPIO_PIN_SET : GPIO_PIN_RESET));

      led_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, (led_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* multiplex tasks (every 250 ms) */
    if (timer1_flag) {
      timer1_flag = 0;
      setTimer1(MUX_PERIOD_MS); /* restart multiplex timer */

      /* advance index and update segments (called in main now) */
      index_led++;
      if (index_led >= MAX_LED) index_led = 0;
      update7SEG(index_led);
    }

    /* main can do other non-blocking work here */
  }
}

/* System Clock, TIM2, GPIO initialization follow (CubeMX-style) */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999; /* 8 MHz / 8000 = 1 kHz */
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;       /* overflow every 10 counts -> 10 ms tick */
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* initial pin levels */
  HAL_GPIO_WritePin(GPIOA, DOT_Pin|LED_RED_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin, GPIO_PIN_SET);

  /* configure pins */
  GPIO_InitStruct.Pin = DOT_Pin|LED_RED_Pin|EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/* Timer ISR - only handles software timers (very small) */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    /* very small: just update software timers */
    timer_run();
  }
}
/* USER CODE END 4 */

/* Error handler and assert (CubeMX default) */
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
