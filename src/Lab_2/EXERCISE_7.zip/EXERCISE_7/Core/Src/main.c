/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - Digital clock example (software timer)
  ******************************************************************************
  * @attention
  *
  * Licensed under BSD 3-Clause license.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdint.h"

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* Display buffer and control */
#define MAX_LED 4
volatile int index_led = 0;
volatile int led_buffer[4] = {1, 2, 3, 0};   // HH:MM -> initial

/* Time variables used in main loop */
int hour = 15, minute = 8, second = 50;

/* LED_RED blink (kept in ISR) */
volatile int led_counter = 100;   // 1 s for LED_RED (100 * 10 ms)
volatile uint8_t led_state = 0;

/* multiplexer: 25*10ms = 250 ms per digit -> 4*250ms = 1s full cycle = 1 Hz */
volatile int mux_counter = 25;

/* ---------------------------------------------------------------------------
   Software timer (skeleton)
   TIMER_CYCLE must equal the ISR tick period (10 ms)
   ---------------------------------------------------------------------------*/
volatile int timer0_counter = 0;
volatile int timer0_flag = 0;
int TIMER_CYCLE = 10; /* 10 ms tick */

void setTimer0(int duration) {
  /* duration in milliseconds */
  timer0_counter = duration / TIMER_CYCLE;
  timer0_flag = 0;
}

void timer_run(void) {
  if (timer0_counter > 0) {
    timer0_counter--;
    if (timer0_counter == 0) timer0_flag = 1;
  }
}

/* Move DOT state to main (non-ISR) */
int dot_state = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
/* helper prototypes */
void update7SEG(int index);
void updateClockBuffer(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* EN polarity: set to match hardware. Here we assume PNP high-side -> active LOW */
#define EN_ACTIVE    GPIO_PIN_RESET
#define EN_INACTIVE  GPIO_PIN_SET

/* segment patterns for digits 0..9 (bit0 = SEG0 (a), bit1 = SEG1 (b), ... bit6 = SEG6 (g))
   pattern bit = 1 -> segment ON (we drive cathode LOW for common-anode displays)
*/
const uint8_t seg_pattern_for_digits[10] =
{
  /*0*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5),        // a b c d e f
  /*1*/  (1<<1)|(1<<2),                                    // b c
  /*2*/  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6),               // a b d e g
  /*3*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6),               // a b c d g
  /*4*/  (1<<5)|(1<<6)|(1<<1)|(1<<2),                      // f g b c
  /*5*/  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3),               // a f g c d
  /*6*/  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6),        // a f e d c g
  /*7*/  (1<<0)|(1<<1)|(1<<2),                             // a b c
  /*8*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), // all
  /*9*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6)         // a b c d f g
};

/* Write pattern bits to SEG0..SEG6 pins (active-low to light segment) */
static void set_segments_from_pattern(uint8_t pattern)
{
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

/* Disable all EN outputs to avoid ghosting */
static void disable_all_en(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
}

/* Enable just the chosen EN index (0..3) */
static void enable_en(uint8_t idx)
{
  disable_all_en();
  switch (idx)
  {
    case 0: HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE); break;
    case 1: HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE); break;
    case 2: HAL_GPIO_WritePin(GPIOA, EN2_Pin, EN_ACTIVE); break;
    case 3: HAL_GPIO_WritePin(GPIOA, EN3_Pin, EN_ACTIVE); break;
    default: break;
  }
}

/* --------------------------------------------------------------------------
   update7SEG: display led_buffer[index] on the 7-seg at position 'index'
   Called from timer ISR for multiplexing.
   --------------------------------------------------------------------------*/
void update7SEG(int index)
{
  if (index < 0 || index >= MAX_LED) return;

  int val = led_buffer[index];
  if (val < 0) val = 0;
  if (val > 9) val = 0; /* safeguard */

  uint8_t pattern = seg_pattern_for_digits[val];

  /* safe update: disable all, set segments, enable selected */
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en((uint8_t)index);
}

/* --------------------------------------------------------------------------
   updateClockBuffer: fills led_buffer[] from current hour and minute.
   Adds leading zeros for single-digit values.
   --------------------------------------------------------------------------*/
void updateClockBuffer(void)
{
  int h = hour;
  int m = minute;

  if (h < 0) h = 0;
  if (h > 23) h = h % 24;

  if (m < 0) m = 0;
  if (m > 59) m = m % 60;

  /* hour tens */
  led_buffer[0] = (h / 10) % 10;
  /* hour units */
  led_buffer[1] = h % 10;
  /* minute tens */
  led_buffer[2] = (m / 10) % 10;
  /* minute units */
  led_buffer[3] = m % 10;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* Start 10 ms timer interrupt */
  HAL_TIM_Base_Start_IT(&htim2);

  /* initialize display and buffer */
  updateClockBuffer();
  index_led = 0;
  update7SEG(index_led); /* display first digit immediately */

  /* initialize software timer for 1s (1000 ms) */
  setTimer0(1000);

  /* Main loop: digital clock skeleton using software timer.
     DOT (PA4) handling moved here and will toggle every 1 s.
  */
  while (1)
  {
    /* non-blocking wait for 1 second via software timer */
    if (timer0_flag)
    {
      /* clear flag and restart timer for next second */
      timer0_flag = 0;
      setTimer0(1000);

      /* advance time by one second (non-blocking) */
      second++;
      if (second >= 60)
      {
        second = 0;
        minute++;
      }
      if (minute >= 60)
      {
        minute = 0;
        hour++;
      }
      if (hour >= 24)
      {
        hour = 0;
      }

      /* update display buffer to show new time */
      updateClockBuffer();

      /* Toggle DOT (connected to PA4) here (now in main, not ISR) */
      dot_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, DOT_Pin, (dot_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* main can do other non-blocking tasks here */
  }
}

/* System clock and peripheral init below (standard CubeMX style) */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief TIM2 Initialization Function (10 ms tick)
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999; // 8 MHz / 8000 = 1 kHz
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;       // overflow every 10 counts -> 10 ms tick
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Initialize pin output levels:
     - EN lines: set to INACTIVE according to EN polarity macro
     - DOT, LED_RED: start LOW
     - Segments: off (cathodes HIGH for common-anode)
  */
  HAL_GPIO_WritePin(GPIOA, DOT_Pin|LED_RED_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin, GPIO_PIN_SET);

  /* Configure GPIOA pins: DOT, LED_RED, EN0..EN3 */
  GPIO_InitStruct.Pin = DOT_Pin|LED_RED_Pin|EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Configure GPIOB pins: SEG0..SEG6 */
  GPIO_InitStruct.Pin = SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/* Timer ISR - called every 10 ms */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    /* run software timers first (very quick) */
    timer_run();

    /* LED_RED blink every 1s (kept in ISR) */
    if (--led_counter <= 0)
    {
      led_counter = 100;
      led_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, (led_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* Multiplexing: advance index every 250 ms */
    if (--mux_counter <= 0)
    {
      mux_counter = 25; /* 25 * 10 ms = 250 ms */
      index_led++;
      if (index_led >= MAX_LED) index_led = 0;
      update7SEG(index_led);
    }
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name and line number where assert_param error occurred.
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
