/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body — 8x8 matrix animation + 7-seg clock
  ******************************************************************************
  * @attention
  *
  * Licensed under BSD 3-Clause license.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "stdint.h"

/* ----------------- Configuration ----------------- */
#define TIMER_CYCLE_MS        10
#define MUX_PERIOD_MS         250
#define MATRIX_COL_PERIOD_MS  2    /* per-column scan (will be ceil-divided) */
#define ANIM_STEP_MS         150   /* animation step interval */
#define HOLD_FULL_MS         500
/* ------------------------------------------------- */

TIM_HandleTypeDef htim2;

/* 7-seg stuff */
#define MAX_LED 4
volatile int index_led = 0;
volatile int led_buffer[4] = {1,2,3,0};
int hour = 15, minute = 8, second = 50;

/* software timers (tick = 10 ms) */
volatile int timer0_counter = 0; /* 1s */
volatile int timer0_flag = 0;
volatile int timer1_counter = 0; /* 7-seg multiplex */
volatile int timer1_flag = 0;
volatile int timer2_counter = 0; /* matrix column multiplex */
volatile int timer2_flag = 0;
volatile int timer3_counter = 0; /* animation step */
volatile int timer3_flag = 0;
int TIMER_CYCLE = TIMER_CYCLE_MS;

/* DOT / LED */
int dot_state = 0;
int led_state = 0;

/* Matrix */
#define A_LEN 8
#define GAP 3
#define TAPE_LEN (A_LEN + GAP + A_LEN + GAP) /* 8 + 3 + 8 + 3 = 22 */
#define MAX_LED_MATRIX 8

int matrix_scan_index = 0; /* which column currently being scanned (0..7) */

/* Base A bitmap (8 columns) provided by you */
static const uint8_t A_cols[A_LEN] = {
    0b11111000,
    0b11111100,
    0b00110110,
    0b00110011,
    0b00110011,
    0b00110110,
    0b11111100,
    0b11111000
};

/* The tape: A + GAP blanks + A + GAP blanks */
uint8_t tape[TAPE_LEN];
/* Display buffer (current 8 columns shown) */
uint8_t matrix_buffer[8];

/* Animation state */
int tape_pos = 0; /* window start index on tape, 0..TAPE_LEN-1 */

typedef enum {
  PHASE_HOLD_FULL,
  PHASE_SHIFT_LEFT_TO_SECOND_A,
  PHASE_HOLD_SECOND,
  PHASE_SHIFT_RIGHT_TO_FIRST_A
} anim_phase_t;

anim_phase_t anim_phase = PHASE_HOLD_FULL;
int anim_hold_steps = 0;

/* Polarity — change if your wiring differs */
#define COL_ACTIVE      GPIO_PIN_RESET
#define COL_INACTIVE    GPIO_PIN_SET
#define ROW_ACTIVE      GPIO_PIN_RESET
#define ROW_INACTIVE    GPIO_PIN_SET
#define EN_ACTIVE       GPIO_PIN_RESET
#define EN_INACTIVE     GPIO_PIN_SET

/* segment patterns for 0..9 */
const uint8_t seg_pattern_for_digits[10] = {
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5), /*0*/
  (1<<1)|(1<<2), /*1*/
  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6), /*2*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6), /*3*/
  (1<<5)|(1<<6)|(1<<1)|(1<<2), /*4*/
  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3), /*5*/
  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6), /*6*/
  (1<<0)|(1<<1)|(1<<2), /*7*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), /*8*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6) /*9*/
};

/* Forward prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

void setTimer0(int ms);
void setTimer1(int ms);
void setTimer2(int ms);
void setTimer3(int ms);
void timer_run(void);

void update7SEG(int index);
void updateClockBuffer(void);

void updateLEDMatrix(int col_index); /* scans one column */
void build_tape(void);
void fill_matrix_from_tape(void);
void anim_step(void);

/* small helpers for 7-seg */
static void set_segments_from_pattern(uint8_t pattern)
{
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}
static void disable_all_en(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
}
static void enable_en(uint8_t idx)
{
  disable_all_en();
  switch (idx) {
    case 0: HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE); break;
    case 1: HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE); break;
    case 2: HAL_GPIO_WritePin(GPIOA, EN2_Pin, EN_ACTIVE); break;
    case 3: HAL_GPIO_WritePin(GPIOA, EN3_Pin, EN_ACTIVE); break;
  }
}

/* 7-seg update (called from main) */
void update7SEG(int index)
{
  if (index < 0 || index >= MAX_LED) return;
  int val = led_buffer[index];
  if (val < 0 || val > 9) val = 0;
  uint8_t pattern = seg_pattern_for_digits[val];
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en((uint8_t)index);
}

void updateClockBuffer(void)
{
  int h = hour, m = minute;
  if (h < 0) h = 0;
  if (h >= 24) h %= 24;
  if (m < 0) m = 0;
  if (m >= 60) m %= 60;
  led_buffer[0] = (h / 10) % 10;
  led_buffer[1] = h % 10;
  led_buffer[2] = (m / 10) % 10;
  led_buffer[3] = m % 10;
}

/* Timers: ceiling division so <TIMER_CYCLE still becomes 1 tick */
void setTimer0(int ms) { timer0_counter = (ms + TIMER_CYCLE - 1) / TIMER_CYCLE; timer0_flag = 0; }
void setTimer1(int ms) { timer1_counter = (ms + TIMER_CYCLE - 1) / TIMER_CYCLE; timer1_flag = 0; }
void setTimer2(int ms) { timer2_counter = (ms + TIMER_CYCLE - 1) / TIMER_CYCLE; timer2_flag = 0; }
void setTimer3(int ms) { timer3_counter = (ms + TIMER_CYCLE - 1) / TIMER_CYCLE; timer3_flag = 0; }

void timer_run(void)
{
  if (timer0_counter > 0 && --timer0_counter == 0) timer0_flag = 1;
  if (timer1_counter > 0 && --timer1_counter == 0) timer1_flag = 1;
  if (timer2_counter > 0 && --timer2_counter == 0) timer2_flag = 1;
  if (timer3_counter > 0 && --timer3_counter == 0) timer3_flag = 1;
}

/* Build tape with A + GAP blanks + A + GAP blanks */
void build_tape(void)
{
  int p = 0;
  /* first A */
  for (int i = 0; i < A_LEN; i++) tape[p++] = A_cols[i];
  /* gap */
  for (int i = 0; i < GAP; i++) tape[p++] = 0x00;
  /* second A */
  for (int i = 0; i < A_LEN; i++) tape[p++] = A_cols[i];
  /* trailing gap */
  for (int i = 0; i < GAP; i++) tape[p++] = 0x00;
  /* p should equal TAPE_LEN */
}

/* Fill matrix_buffer (8 cols) with tape window starting at tape_pos */
void fill_matrix_from_tape(void)
{
  for (int i = 0; i < 8; i++) {
    int idx = (tape_pos + i) % TAPE_LEN;
    matrix_buffer[i] = tape[idx];
  }
}

/* matrix column scan: writes rows and enables single column */
void updateLEDMatrix(int col_index)
{
  if (col_index < 0 || col_index >= 8) return;

  const uint16_t colPins[8] = {
    COL0_Pin, COL1_Pin, COL2_Pin, COL3_Pin,
    COL4_Pin, COL5_Pin, COL6_Pin, COL7_Pin
  };
  const uint16_t rowPins[8] = {
    ROW0_Pin, ROW1_Pin, ROW2_Pin, ROW3_Pin,
    ROW4_Pin, ROW5_Pin, ROW6_Pin, ROW7_Pin
  };

  /* safe sequence: disable all columns, set rows inactive, set rows pattern, enable target column */
  for (int c = 0; c < 8; c++) HAL_GPIO_WritePin(GPIOA, colPins[c], COL_INACTIVE);
  for (int r = 0; r < 8; r++) HAL_GPIO_WritePin(GPIOB, rowPins[r], ROW_INACTIVE);

  uint8_t colByte = matrix_buffer[col_index];
  for (int r = 0; r < 8; r++) {
    GPIO_PinState s = (colByte & (1 << r)) ? ROW_ACTIVE : ROW_INACTIVE;
    HAL_GPIO_WritePin(GPIOB, rowPins[r], s);
  }

  HAL_GPIO_WritePin(GPIOA, colPins[col_index], COL_ACTIVE);
}

/* Animation step: controls tape_pos and holds */
/* Show first A when tape_pos == 0; second A fully visible when tape_pos == A_LEN + GAP */
void anim_step(void)
{
  switch (anim_phase) {
    case PHASE_HOLD_FULL:
      if (--anim_hold_steps <= 0) {
        anim_phase = PHASE_SHIFT_LEFT_TO_SECOND_A;
      }
      break;

    case PHASE_SHIFT_LEFT_TO_SECOND_A:
      tape_pos = (tape_pos + 1) % TAPE_LEN;
      fill_matrix_from_tape();
      if (tape_pos == (A_LEN + GAP)) { /* second A fully in window */
        anim_phase = PHASE_HOLD_SECOND;
        anim_hold_steps = (HOLD_FULL_MS + ANIM_STEP_MS/2) / ANIM_STEP_MS;
      }
      break;

    case PHASE_HOLD_SECOND:
      if (--anim_hold_steps <= 0) {
        anim_phase = PHASE_SHIFT_RIGHT_TO_FIRST_A;
      }
      break;

    case PHASE_SHIFT_RIGHT_TO_FIRST_A:
      tape_pos = (tape_pos - 1 + TAPE_LEN) % TAPE_LEN;
      fill_matrix_from_tape();
      if (tape_pos == 0) { /* back to first A full */
        anim_phase = PHASE_HOLD_FULL;
        anim_hold_steps = (HOLD_FULL_MS + ANIM_STEP_MS/2) / ANIM_STEP_MS;
      }
      break;
  }
}

/* ---------------------- main ---------------------- */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  HAL_TIM_Base_Start_IT(&htim2);

  /* prepare tape and initial window */
  build_tape();
  tape_pos = 0;
  fill_matrix_from_tape();

  /* init 7-seg buffer */
  updateClockBuffer();

  /* timers */
  setTimer0(1000);
  setTimer1(MUX_PERIOD_MS);
  setTimer2(MATRIX_COL_PERIOD_MS);
  setTimer3(ANIM_STEP_MS);

  anim_phase = PHASE_HOLD_FULL;
  anim_hold_steps = (HOLD_FULL_MS + ANIM_STEP_MS/2) / ANIM_STEP_MS;

  matrix_scan_index = 0;
  updateLEDMatrix(matrix_scan_index);
  index_led = 0;
  update7SEG(index_led);

  while (1)
  {
    /* 1s tasks */
    if (timer0_flag) {
      timer0_flag = 0;
      setTimer0(1000);
      second++;
      if (second >= 60) { second = 0; minute++; }
      if (minute >= 60) { minute = 0; hour++; }
      if (hour >= 24) hour = 0;
      updateClockBuffer();

      dot_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, DOT_Pin, (dot_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
      led_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, (led_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* 7-seg multiplex tasks */
    if (timer1_flag) {
      timer1_flag = 0;
      setTimer1(MUX_PERIOD_MS);
      index_led++;
      if (index_led >= MAX_LED) index_led = 0;
      update7SEG(index_led);
    }

    /* matrix per-column multiplex (fast) */
    if (timer2_flag) {
      timer2_flag = 0;
      setTimer2(MATRIX_COL_PERIOD_MS);
      matrix_scan_index++;
      if (matrix_scan_index >= MAX_LED_MATRIX) matrix_scan_index = 0;
      updateLEDMatrix(matrix_scan_index);
    }

    /* animation (slow) */
    if (timer3_flag) {
      timer3_flag = 0;
      setTimer3(ANIM_STEP_MS);
      anim_step();
    }

    /* main loop can do other non-blocking work */
  }
}

/* ---------------- HAL / MX functions (unchanged structure) ---------------- */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999; /* e.g. 8MHz/8000 = 1kHz */
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;       /* overflow every 10 counts -> 10 ms tick */
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* default: columns inactive, rows inactive, segs inactive, EN inactive */
  HAL_GPIO_WritePin(GPIOA, COL0_Pin|COL1_Pin|COL2_Pin|COL3_Pin
                          |COL4_Pin|COL5_Pin|COL6_Pin|COL7_Pin
                          |DOT_Pin|LED_RED_Pin
                          |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, COL_INACTIVE);

  HAL_GPIO_WritePin(GPIOB, ROW0_Pin|ROW1_Pin|ROW2_Pin|ROW3_Pin
                          |ROW4_Pin|ROW5_Pin|ROW6_Pin|ROW7_Pin
                          |SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                          |SEG4_Pin|SEG5_Pin|SEG6_Pin, ROW_INACTIVE);

  /* Configure column pins (PA) */
  GPIO_InitStruct.Pin = COL0_Pin|COL1_Pin|COL2_Pin|COL3_Pin
                        |COL4_Pin|COL5_Pin|COL6_Pin|COL7_Pin
                        |DOT_Pin|LED_RED_Pin
                        |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Configure row pins and 7-seg segment pins (PB) */
  GPIO_InitStruct.Pin = ROW0_Pin|ROW1_Pin|ROW2_Pin|ROW3_Pin
                        |ROW4_Pin|ROW5_Pin|ROW6_Pin|ROW7_Pin
                        |SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                        |SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2) timer_run();
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file; (void)line;
}
#endif

/* ---------------- End of file ---------------- */

