/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Licensed under BSD 3-Clause license.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stdint.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* multiplex step: 250 ms per digit -> 4*250ms = 1s full cycle */
#define MUX_PERIOD_MS 250

/* Software timers (ISR tick period = 10 ms) */
#define TIMER_CYCLE_MS 10

/* matrix column multiplex period in ms (per column) */
#define MATRIX_COL_PERIOD_MS 2
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* display buffer and control (7-seg) */
#define MAX_LED 4
volatile int index_led = 0;
volatile int led_buffer[4] = {1,2,3,0};   /* HH:MM buffer */

/* clock variables (main loop) */
int hour = 15, minute = 8, second = 50;

/* Software timers (TIMER_CYCLE must equal ISR tick period = 10 ms) */
volatile int timer0_counter = 0; /* 1s timer (clock tick) */
volatile int timer0_flag = 0;

volatile int timer1_counter = 0; /* 250ms timer (7-seg multiplex step) */
volatile int timer1_flag = 0;

volatile int timer2_counter = 0; /* matrix column timer (~2ms per column) */
volatile int timer2_flag = 0;

int TIMER_CYCLE = TIMER_CYCLE_MS; /* ms, ISR tick period */

/* DOT and LED_RED states (handled in main on timer0 expiry) */
int dot_state = 0;
int led_state = 0;

/* LED matrix variables */
const int MAX_LED_MATRIX = 8;
int index_led_matrix = 0;

/* matrix_buffer provided by you (8 bytes, one per column) */
uint8_t matrix_buffer[8] = {
    0b11111000,
    0b11111100,
    0b00110110,
    0b00110011,
    0b00110011,
    0b00110110,
    0b11111100,
    0b11111000
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* helper prototypes */
void update7SEG(int index);
void updateClockBuffer(void);

/* software-timer helpers (now use ceiling division) */
void setTimer0(int duration_ms);
void setTimer1(int duration_ms);
void setTimer2(int duration_ms);
void timer_run(void);

/* matrix */
void updateLEDMatrix(int index);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define EN_ACTIVE    GPIO_PIN_RESET
#define EN_INACTIVE  GPIO_PIN_SET

/* segment patterns for digits 0..9 (bit0=SEG0(a), bit1=SEG1(b), ..., bit6=SEG6(g)) */
const uint8_t seg_pattern_for_digits[10] =
{
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5),        /*0*/
  (1<<1)|(1<<2),                                    /*1*/
  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6),               /*2*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6),               /*3*/
  (1<<5)|(1<<6)|(1<<1)|(1<<2),                      /*4*/
  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3),               /*5*/
  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6),        /*6*/
  (1<<0)|(1<<1)|(1<<2),                             /*7*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), /*8*/
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6)         /*9*/
};

/* low-level helpers to write segments and EN lines */
static void set_segments_from_pattern(uint8_t pattern)
{
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static void disable_all_en(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
}

static void enable_en(uint8_t idx)
{
  disable_all_en();
  switch (idx)
  {
    case 0: HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE); break;
    case 1: HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE); break;
    case 2: HAL_GPIO_WritePin(GPIOA, EN2_Pin, EN_ACTIVE); break;
    case 3: HAL_GPIO_WritePin(GPIOA, EN3_Pin, EN_ACTIVE); break;
    default: break;
  }
}

/* --------------------------------------------------------------------------
   update7SEG(int index) - moved out of ISR, called from main when timer1_flag
   index: 0..3 -> display led_buffer[index] on that 7-seg
   --------------------------------------------------------------------------*/
void update7SEG(int index)
{
  if (index < 0 || index >= MAX_LED) return;

  int val = led_buffer[index];
  if (val < 0) val = 0;
  if (val > 9) val = 0; /* safeguard */

  uint8_t pattern = seg_pattern_for_digits[val];

  /* safe update: disable all, set segments, enable selected */
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en((uint8_t)index);
}

/* The new file had an update_display_for_index; reuse but base on led_buffer */
static void update_display_for_index(uint8_t idx)
{
  if (idx >= 4) return;
  uint8_t val = led_buffer[idx];
  uint8_t pattern = seg_pattern_for_digits[val];
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en(idx);
}

/* --------------------------------------------------------------------------
   updateClockBuffer: fill led_buffer[] from hour/minute (leading zeros)
   --------------------------------------------------------------------------*/
void updateClockBuffer(void)
{
  int h = hour;
  int m = minute;

  if (h < 0) h = 0;
  if (h >= 24) h %= 24;
  if (m < 0) m = 0;
  if (m >= 60) m %= 60;

  led_buffer[0] = (h / 10) % 10;
  led_buffer[1] = h % 10;
  led_buffer[2] = (m / 10) % 10;
  led_buffer[3] = m % 10;
}

/* --------------------------------------------------------------------------
   Software timer API (use ceiling when converting ms->ticks)
   --------------------------------------------------------------------------*/
static inline int ms_to_ticks(int ms)
{
  if (ms <= 0) return 0;
  /* ceiling division to avoid zero when ms < TIMER_CYCLE */
  return (ms + TIMER_CYCLE - 1) / TIMER_CYCLE;
}

void setTimer0(int duration_ms)
{
  timer0_counter = ms_to_ticks(duration_ms);
  if (timer0_counter == 0) timer0_counter = 1;
  timer0_flag = 0;
}
void setTimer1(int duration_ms)
{
  timer1_counter = ms_to_ticks(duration_ms);
  if (timer1_counter == 0) timer1_counter = 1;
  timer1_flag = 0;
}
void setTimer2(int duration_ms)
{
  timer2_counter = ms_to_ticks(duration_ms);
  if (timer2_counter == 0) timer2_counter = 1;
  timer2_flag = 0;
}

/* called from ISR */
void timer_run(void)
{
  if (timer0_counter > 0) {
    timer0_counter--;
    if (timer0_counter == 0) timer0_flag = 1;
  }
  if (timer1_counter > 0) {
    timer1_counter--;
    if (timer1_counter == 0) timer1_flag = 1;
  }
  if (timer2_counter > 0) {
    timer2_counter--;
    if (timer2_counter == 0) timer2_flag = 1;
  }
}

/* --------------------------------------------------------------------------
   updateLEDMatrix(int index):
   - set all columns = SET (disabled)
   - write row pins: if bit==1 -> RESET, else SET  (matches your ULN2803 wiring)
   - then pull the selected column pin RESET (enable that column)
   --------------------------------------------------------------------------*/
void updateLEDMatrix(int index)
{
  if (index < 0 || index >= MAX_LED_MATRIX) return;

  /* column pins on GPIOA: COL0..COL7 as requested */
  const uint16_t colPins[8] = {
    COL0_Pin, /* GPIO_PIN_2 */
    COL1_Pin, /* GPIO_PIN_3 */
    COL2_Pin, /* GPIO_PIN_10 */
    COL3_Pin, /* GPIO_PIN_11 */
    COL4_Pin, /* GPIO_PIN_12 */
    COL5_Pin, /* GPIO_PIN_13 */
    COL6_Pin, /* GPIO_PIN_14 */
    COL7_Pin  /* GPIO_PIN_15 */
  };

  /* row pins on GPIOB: ROW0..ROW7 (PB8..PB15) */
  const uint16_t rowPins[8] = {
    ROW0_Pin, /* GPIO_PIN_8 */
    ROW1_Pin, /* GPIO_PIN_9 */
    ROW2_Pin, /* GPIO_PIN_10 */
    ROW3_Pin, /* GPIO_PIN_11 */
    ROW4_Pin, /* GPIO_PIN_12 */
    ROW5_Pin, /* GPIO_PIN_13 */
    ROW6_Pin, /* GPIO_PIN_14 */
    ROW7_Pin  /* GPIO_PIN_15 */
  };

  /* 1) set all columns = SET (disabled) */
  for (int c = 0; c < 8; c++) {
    HAL_GPIO_WritePin(GPIOA, colPins[c], GPIO_PIN_SET);
  }

  /* 2) write rows from matrix_buffer[index]
     per your snippet: when bit==1 -> RESET (turn on row), else SET (off)
  */
  uint8_t pattern = matrix_buffer[index];
  for (int r = 0; r < 8; r++) {
    GPIO_PinState ps = (pattern & (1 << r)) ? GPIO_PIN_RESET : GPIO_PIN_SET;
    HAL_GPIO_WritePin(GPIOB, rowPins[r], ps);
  }

  /* 3) activate the selected column by pulling it RESET */
  HAL_GPIO_WritePin(GPIOA, colPins[index], GPIO_PIN_RESET);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* start timer interrupt (10 ms tick) */
  HAL_TIM_Base_Start_IT(&htim2);

  /* initialize time display buffer */
  updateClockBuffer();

  /* initialize timers:
     timer0 -> 1s clock tick (advance seconds, toggle DOT and LED_RED)
     timer1 -> 250ms multiplex step (advance displayed 7-seg digit)
     timer2 -> ~MATRIX_COL_PERIOD_MS per matrix column (matrix multiplex)
  */
  setTimer0(1000);
  setTimer1(MUX_PERIOD_MS);
  setTimer2(MATRIX_COL_PERIOD_MS);

  /* ensure initial display is shown */
  index_led = 0;
  update_display_for_index((uint8_t)index_led);

  index_led_matrix = 0;
  updateLEDMatrix(index_led_matrix);

  /* Infinite loop */
  while (1)
  {
    /* 1 second tasks */
    if (timer0_flag) {
      timer0_flag = 0;
      setTimer0(1000); /* restart 1s timer */

      /* advance clock */
      second++;
      if (second >= 60) { second = 0; minute++; }
      if (minute >= 60) { minute = 0; hour++; }
      if (hour >= 24)   { hour = 0; }

      /* refresh display buffer */
      updateClockBuffer();

      /* toggle DOT (PAx) and LED_RED (PAx) */
      dot_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, DOT_Pin, (dot_state ? GPIO_PIN_SET : GPIO_PIN_RESET));

      led_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, (led_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* 7-seg multiplex tasks (every MUX_PERIOD_MS) */
    if (timer1_flag) {
      timer1_flag = 0;
      setTimer1(MUX_PERIOD_MS); /* restart multiplex timer */

      /* advance index and update segments (called in main now) */
      index_led++;
      if (index_led >= MAX_LED) index_led = 0;
      update_display_for_index((uint8_t)index_led);
    }

    /* matrix multiplex tasks (every MATRIX_COL_PERIOD_MS (ceiled) ) */
    if (timer2_flag) {
      timer2_flag = 0;
      setTimer2(MATRIX_COL_PERIOD_MS); /* restart matrix column timer */

      index_led_matrix++;
      if (index_led_matrix >= MAX_LED_MATRIX) index_led_matrix = 0;
      updateLEDMatrix(index_led_matrix);
    }

    /* main can do other non-blocking work here */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999; /* if APB1 timer clock 8MHz -> 8MHz/8000 = 1kHz */
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;       /* overflow every 10 counts -> 10 ms tick */
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* ---- Set default levels:
       - columns (GPIOA COL0..COL7) = SET (disabled)
       - rows    (GPIOB ROW0..ROW7) = SET (all off)
       - keep existing 7-seg pins as configured
  */
  HAL_GPIO_WritePin(GPIOA, COL0_Pin|COL1_Pin|COL2_Pin|COL3_Pin
                          |COL4_Pin|COL5_Pin|COL6_Pin|COL7_Pin
                          |DOT_Pin|LED_RED_Pin
                          |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, GPIO_PIN_SET);

  HAL_GPIO_WritePin(GPIOB, ROW0_Pin|ROW1_Pin|ROW2_Pin|ROW3_Pin
                          |ROW4_Pin|ROW5_Pin|ROW6_Pin|ROW7_Pin
                          |SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                          |SEG4_Pin|SEG5_Pin|SEG6_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : columns on PA (COL0..COL7) + DOT + LED_RED + ENx */
  GPIO_InitStruct.Pin = COL0_Pin|COL1_Pin|COL2_Pin|COL3_Pin
                        |COL4_Pin|COL5_Pin|COL6_Pin|COL7_Pin
                        |DOT_Pin|LED_RED_Pin
                        |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : rows and segs on PB (ROW0..ROW7, SEG0..SEG6) */
  GPIO_InitStruct.Pin = ROW0_Pin|ROW1_Pin|ROW2_Pin|ROW3_Pin
                        |ROW4_Pin|ROW5_Pin|ROW6_Pin|ROW7_Pin
                        |SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                        |SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/* Timer ISR - only handles software timers (very small) */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    /* very small: just update software timers */
    timer_run();
  }
}
/* USER CODE END 4 */

/* Error handler and assert (CubeMX default) */
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
