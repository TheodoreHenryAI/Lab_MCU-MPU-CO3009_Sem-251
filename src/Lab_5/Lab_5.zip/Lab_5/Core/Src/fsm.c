/*
 * fsm.c
 *
 *  Created on: Nov 6, 2025
 *      Author: thanh
 */

#include "fsm.h"

enum command_parser_state {IDLE, READ, STOP_READ};
enum uart_communication_state {RST, OK};

uint8_t buffer_byte = 0;
uint8_t buffer[MAX_BUFFER_SIZE];
uint8_t index_buffer = 0;
uint8_t buffer_flag = 0;

uint8_t cmd_status = IDLE;
uint8_t cmd_flag = OK;
uint8_t cmd_data[MAX_CMD_SIZE];
uint8_t cmd_data_index = 0;
int ADC_value = 0;

// HELPER FUNCTION START
int isRST(uint8_t str[]){
	if (str[0] == 'R' && str[1] == 'S' && str[2] == 'T') {
		return 1;
	}
	return 0;
}

int isOK(uint8_t str[]){
	if (str[0] == 'O' && str[1] == 'K')
		return 1;
	return 0;
}

void command_parser_fsm(ADC_HandleTypeDef* hadc1, UART_HandleTypeDef* huart2) {
	switch(cmd_status) {
		case IDLE:
			if(buffer_byte == '!')
				cmd_status = READ;
			break;
		case READ:
			if(buffer_byte != '!' && buffer_byte != '#')
			{
				cmd_data[cmd_data_index] = buffer_byte;
				cmd_data_index++;
				if(cmd_data_index > 3)
				{
					cmd_status = STOP_READ;
					cmd_data_index = 0;
				}
			}
			if (buffer_byte == '#' || buffer_byte == '!')
			{
				cmd_status = STOP_READ;
				cmd_data_index = 0;
			}
			break;
		case STOP_READ:
			if (isRST(cmd_data))
			{
				cmd_flag = RST;
			}
			else if (isOK(cmd_data))
			{
				cmd_flag = OK;
			}
			cmd_status = IDLE;
			break;
		default:
			break;
	}
}

void uart_communication_fsm(ADC_HandleTypeDef* hadc1, UART_HandleTypeDef* huart2) {
	char str[50];
	switch(cmd_flag){
		case RST:
			if(timer1_flag == 1){
				ADC_value = HAL_ADC_GetValue(hadc1);
				HAL_UART_Transmit(huart2, (void *)str, sprintf(str, "!ADC=%d#\r\n",ADC_value), 50);
				setTimer1(1000);
			}
		    break;
		case OK:
			ADC_value = -1;
			break;
		default:
			break;
	}
}
