/*
 * fsm.h
 *
 *  Created on: Nov 6, 2025
 *      Author: thanh
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_

#include "main.h"
#include "timer.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"

#define MAX_BUFFER_SIZE  30
#define MAX_CMD_SIZE 5

extern uint8_t buffer_byte;
extern uint8_t buffer[MAX_BUFFER_SIZE];
extern uint8_t index_buffer;
extern uint8_t buffer_flag;

void command_parser_fsm(ADC_HandleTypeDef* hadc1, UART_HandleTypeDef* huart2);
void uart_communication_fsm(ADC_HandleTypeDef* hadc1, UART_HandleTypeDef* huart2);

#endif /* INC_FSM_H_ */
