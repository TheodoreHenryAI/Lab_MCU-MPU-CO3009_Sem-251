/*
 * timer.h
 *
 *  Created on: Nov 6, 2025
 *      Author: thanh
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#define TICK 10

extern int timer1_flag;
extern int timer2_flag;

void setTimer1(int duration);
void setTimer2(int duration);
void timerRun();

#endif /* INC_TIMER_H_ */
