/*
 * led_display.h
 *
 *  Created on: Oct 8, 2025
 *      Author: thanh
 */

#ifndef INC_LED_DISPLAY_H_
#define INC_LED_DISPLAY_H_

void led_mode_display(int index);

#endif /* INC_LED_DISPLAY_H_ */
