/*
 * led_display.c
 *
 *  Created on: Oct 8, 2025
 *      Author: thanh
 */

#include "main.h"

// Display selected mode on LEDs

int pinPort[4] = { GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6};

void led_mode_display(int index){
	switch(index){
	case 1:
		HAL_GPIO_WritePin(GPIOA, pinPort[0], RESET);
		HAL_GPIO_WritePin(GPIOA, pinPort[1], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[2], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[3], SET);
		break;
	case 2:
		HAL_GPIO_WritePin(GPIOA, pinPort[0], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[1], RESET);
		HAL_GPIO_WritePin(GPIOA, pinPort[2], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[3], SET);
		break;
	case 3:
		HAL_GPIO_WritePin(GPIOA, pinPort[0], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[1], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[2], RESET);
		HAL_GPIO_WritePin(GPIOA, pinPort[3], SET);
		break;
	case 4:
		HAL_GPIO_WritePin(GPIOA, pinPort[0], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[1], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[2], SET);
		HAL_GPIO_WritePin(GPIOA, pinPort[3], RESET);
		break;
	}
}
