/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* base 10 ms tick variables -----------------------------*/
volatile int counter = 100;   // existing LED_RED toggle every 1s (100 * 10 ms)
volatile int mux_counter = 50; // 50 * 10 ms = 500 ms (switch between displays)
/* which display is currently active: 0 = first display (EN0), 1 = second (EN1) */
volatile uint8_t current_display = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* helper prototypes */
static void enable_display(uint8_t idx);
static void disable_both_displays(void);
static void set_segments_from_pattern(uint8_t pattern);
static void show_digit_pattern(uint8_t digit_idx); // 0: show '1' on first, 1: show '2' on second
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*
  NOTES about polarity:
  - These macros set the GPIO level used to enable/disable the display anode.
  - For many PNP high-side switches the control line may be active-LOW.
    If your hardware enables the anode when ENx is LOW, change EN_ACTIVE to GPIO_PIN_RESET
    and EN_INACTIVE to GPIO_PIN_SET.
  - Default below assumes EN_ACTIVE is GPIO_PIN_SET (active HIGH). Adjust if needed.
*/
#define EN_ACTIVE    GPIO_PIN_RESET
#define EN_INACTIVE  GPIO_PIN_SET

/* Segment bit mapping (bit0 -> SEG0 (a), bit1 -> SEG1 (b), ... bit6 -> SEG6 (g))
   We define pattern bits = 1 meaning "segment ON". Since you're using common-anode
   displays, the cathode must be driven LOW to turn on the segment. We will convert
   these bits into actual GPIO pin levels when writing outputs.
*/
const uint8_t seg_pattern_for_digits[10] =
{
  /*0*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5),        // a b c d e f
  /*1*/  (1<<1)|(1<<2),                                    // b c
  /*2*/  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6),               // a b d e g
  /*3*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6),               // a b c d g
  /*4*/  (1<<5)|(1<<6)|(1<<1)|(1<<2),                      // f g b c
  /*5*/  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3),               // a f g c d
  /*6*/  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6),        // a f e d c g
  /*7*/  (1<<0)|(1<<1)|(1<<2),                             // a b c
  /*8*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), // all
  /*9*/  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6)         // a b c d f g
};

/* Pins order: SEG0..SEG6 corresponds to bits 0..6 */
/* Helper: write pattern to SEG0..SEG6 pins (active-low to light) */
static void set_segments_from_pattern(uint8_t pattern)
{
  /* pattern bit = 1 -> segment ON -> write cathode LOW (GPIO_PIN_RESET)
     pattern bit = 0 -> segment OFF -> cathode HIGH (GPIO_PIN_SET)
  */

  /* SEG0 */
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG1 */
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG2 */
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG3 */
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG4 */
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG5 */
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  /* SEG6 */
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

/* Disable both EN pins (prevent ghosting while updating segments) */
static void disable_both_displays(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_INACTIVE);
  HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_INACTIVE);
}

/* Enable the requested display (idx = 0 -> EN0, idx = 1 -> EN1) */
static void enable_display(uint8_t idx)
{
  if (idx == 0)
  {
    HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE);
    HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_INACTIVE);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_INACTIVE);
    HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE);
  }
}

/* Show the requested digit on the currently selected display.
   digit_idx: 0 => show '1' (on first display)
              1 => show '2' (on second display)
*/
static void show_digit_pattern(uint8_t digit_idx)
{
  uint8_t pattern = 0;

  if (digit_idx == 0) {
    /* show '1' */
    pattern = seg_pattern_for_digits[1];
  } else {
    /* show '2' */
    pattern = seg_pattern_for_digits[2];
  }

  /* update outputs safely: disable both anodes, set segments, then enable desired anode */
  disable_both_displays();
  set_segments_from_pattern(pattern);
  enable_display(digit_idx);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */
  /* Start the timer (10 ms tick defined in MX_TIM2_Init) */
  HAL_TIM_Base_Start_IT(&htim2);

  /* Initialize display state: show '1' on display 0 */
  current_display = 0;
  show_digit_pattern(current_display);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* All action is in timer ISR: no busy work here. */
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig     = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance               = TIM2;
  htim2.Init.Prescaler         = 7999; // 8 MHz / 8000 = 1 kHz (1 ms tick)
  htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim2.Init.Period            = 9;    // 10 counts -> 10 ms overflow
  htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_RED_Pin|EN0_Pin|EN1_Pin, EN_INACTIVE);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                          |SEG4_Pin|SEG5_Pin|SEG6_Pin, GPIO_PIN_SET); // segments off (common-anode)

  /*Configure GPIO pins : LED_RED_Pin EN0_Pin EN1_Pin */
  GPIO_InitStruct.Pin = LED_RED_Pin|EN0_Pin|EN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG0_Pin ... SEG6_Pin */
  GPIO_InitStruct.Pin = SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin
                          |SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/* Timer interrupt callback (fires every 10 ms) */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    /* existing LED_RED 1s toggle */
    counter--;
    if (counter <= 0)
    {
      counter = 100; // 100 * 10ms = 1s
      HAL_GPIO_TogglePin(LED_RED_GPIO_Port, LED_RED_Pin);
    }

    /* multiplex switching: toggle which display is active every 0.5s */
    mux_counter--;
    if (mux_counter <= 0)
    {
      mux_counter = 50; // 50 * 10ms = 500 ms
      /* flip display index */
      current_display ^= 1;
      /* update displayed digit accordingly */
      show_digit_pattern(current_display);
    }
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) {}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and line number
  *         where the assert_param error has occurred.
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
