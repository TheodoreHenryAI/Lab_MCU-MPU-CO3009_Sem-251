/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Licensed under BSD 3-Clause license.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
const int MAX_LED = 4;
int index_led = 0;
int led_buffer[4] = {1, 2, 3, 4};   // four digits to show

volatile int dot_counter = 100;   // 1s blink
volatile uint8_t dot_state = 0;

volatile int led_counter = 100;   // 1s blink
volatile uint8_t led_state = 0;

volatile int mux_counter = 25;    // 0.25s per 7-seg digit (so 4*0.25s = 1s total)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN 0 */
#define EN_ACTIVE    GPIO_PIN_RESET
#define EN_INACTIVE  GPIO_PIN_SET

/* Segment patterns for digits 0–9 */
const uint8_t seg_pattern_for_digits[10] =
{
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5),        //0
  (1<<1)|(1<<2),                                    //1
  (1<<0)|(1<<1)|(1<<3)|(1<<4)|(1<<6),               //2
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<6),               //3
  (1<<5)|(1<<6)|(1<<1)|(1<<2),                      //4
  (1<<0)|(1<<5)|(1<<6)|(1<<2)|(1<<3),               //5
  (1<<0)|(1<<5)|(1<<4)|(1<<3)|(1<<2)|(1<<6),        //6
  (1<<0)|(1<<1)|(1<<2),                             //7
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6), //8
  (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<5)|(1<<6)         //9
};

static void set_segments_from_pattern(uint8_t pattern)
{
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin, (pattern & (1<<0)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG1_Pin, (pattern & (1<<1)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG2_Pin, (pattern & (1<<2)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG3_Pin, (pattern & (1<<3)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG4_Pin, (pattern & (1<<4)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG5_Pin, (pattern & (1<<5)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG6_Pin, (pattern & (1<<6)) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static void disable_all_en(void)
{
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
}

static void enable_en(uint8_t idx)
{
  disable_all_en();
  switch (idx)
  {
    case 0: HAL_GPIO_WritePin(GPIOA, EN0_Pin, EN_ACTIVE); break;
    case 1: HAL_GPIO_WritePin(GPIOA, EN1_Pin, EN_ACTIVE); break;
    case 2: HAL_GPIO_WritePin(GPIOA, EN2_Pin, EN_ACTIVE); break;
    case 3: HAL_GPIO_WritePin(GPIOA, EN3_Pin, EN_ACTIVE); break;
  }
}

/* -------------------------------------------------------------------------- */
/* update7SEG: select which digit to show from led_buffer[]                   */
void update7SEG(int index)
{
  if (index < 0 || index >= MAX_LED) return;

  uint8_t val = led_buffer[index];
  if (val > 9) val = 0;  // safeguard

  uint8_t pattern = seg_pattern_for_digits[val];
  disable_all_en();
  set_segments_from_pattern(pattern);
  enable_en(index);
}
/* -------------------------------------------------------------------------- */
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  HAL_TIM_Base_Start_IT(&htim2);

  index_led = 0;
  update7SEG(index_led);

  while (1) {}
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) { Error_Handler(); }
}

static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999; // 8 MHz / 8000 = 1 kHz
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;       // 1 kHz / 10 = 100 Hz -> 10ms tick
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) { Error_Handler(); }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) { Error_Handler(); }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, DOT_Pin|LED_RED_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, EN_INACTIVE);
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin, GPIO_PIN_SET);

  GPIO_InitStruct.Pin = DOT_Pin|LED_RED_Pin|EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = SEG0_Pin|SEG1_Pin|SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin|SEG6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    /* DOT blink every 1s */
    if (--dot_counter <= 0) {
      dot_counter = 100;
      dot_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, DOT_Pin, (dot_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* LED_RED blink every 1s */
    if (--led_counter <= 0) {
      led_counter = 100;
      led_state ^= 1;
      HAL_GPIO_WritePin(GPIOA, LED_RED_Pin, (led_state ? GPIO_PIN_SET : GPIO_PIN_RESET));
    }

    /* Multiplex every 0.25s -> full cycle = 1s */
    if (--mux_counter <= 0) {
      mux_counter = 25;  // 25 * 10ms = 250ms
      index_led++;
      if (index_led >= MAX_LED) index_led = 0;
      update7SEG(index_led);
    }
  }
}
/* USER CODE END 4 */

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
